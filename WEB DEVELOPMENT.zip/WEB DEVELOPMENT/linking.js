const pathName = window.location.pathname;
const pageName = pathName.split("/").pop();

if (pageName === "index.html") {
    const homeLink = document.querySelector(".home");
    if (homeLink) homeLink.classList.add("activeLink");
}
if (pageName === "Register.html") {
    const registerLink = document.querySelector(".register");
    if (registerLink) registerLink.classList.add("activeLink");
}
if (pageName === "converter.html") {
    const converterLink = document.querySelector(".converter");
    if (converterLink) converterLink.classList.add("activeLink");
}
if (pageName === "login.html") {
    const loginLink = document.querySelector(".login");
    if (loginLink) loginLink.classList.add("activeLink");
}
